// Aplicación principal con sistema de roles y autenticación
import React from 'react'
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'
import { AuthProvider } from '@/contexts/AuthContext'
import { CarritoProvider } from '@/contexts/CarritoContext'
import { SystemProvider } from '@/contexts/SystemIntegrationContext'
import { Layout } from '@/components/LayoutNew'
import { LoginNew } from '@/pages/LoginNew'
import { PanelMenuConfig } from '@/components/admin/PanelMenuConfig'
import { AdminDashboardWrapper } from '@/components/admin/AdminDashboard'
import { Dashboard } from '@/pages/Dashboard'
import { Agenda } from '@/pages/Agenda'
import { ExamenesOcupacionales } from '@/pages/ExamenesOcupacionales'
import { EvaluacionesRiesgo } from '@/pages/EvaluacionesRiesgo'
import { Reportes } from '@/pages/Reportes'
import { IA } from '@/pages/IA'
import { Facturacion } from '@/pages/Facturacion'
import { Inventario } from '@/pages/Inventario'
import { Configuracion } from '@/pages/Configuracion'
import { Pacientes } from '@/pages/Pacientes'
import { Certificaciones } from '@/pages/Certificaciones'
import { RayosX } from '@/pages/RayosX'
import { NuevaCita } from '@/pages/NuevaCita'
import { PerfilUsuario } from '@/pages/PerfilUsuario'
import { AlertasMedicas } from '@/pages/AlertasMedicas'
import Tienda from '@/pages/Tienda'
import './App.css'

function AppNew() {
  return (
    <AuthProvider>
      <SystemProvider>
        <CarritoProvider>
          <Router>
            <div className="App">
              <Routes>
                {/* Login - Página pública */}
                <Route path="/login" element={<LoginNew />} />
                
                {/* Rutas protegidas con Layout */}
                <Route path="/" element={<Layout />}>
                  {/* Redirección principal */}
                  <Route index element={<Navigate to="/dashboard" replace />} />
                  
                  {/* Dashboard */}
                  <Route path="dashboard" element={<Dashboard />} />
                  
                  {/* Gestión de pacientes */}
                  <Route path="pacientes" element={<Pacientes />} />
                  
                  {/* Agenda y citas */}
                  <Route path="agenda" element={<Agenda />} />
                  <Route path="agenda/nueva" element={<NuevaCita />} />
                  <Route path="citas" element={<Agenda />} />
                  
                  {/* Alertas médicas */}
                  <Route path="alertas" element={<AlertasMedicas />} />
                  
                  {/* Medicina del trabajo */}
                  <Route path="examenes" element={<ExamenesOcupacionales />} />
                  <Route path="rayos-x" element={<RayosX />} />
                  <Route path="evaluaciones" element={<EvaluacionesRiesgo />} />
                  <Route path="certificaciones" element={<Certificaciones />} />
                  
                  {/* IA y análisis */}
                  <Route path="ia" element={<IA />} />
                  <Route path="analytics" element={<IA />} />
                  
                  {/* Gestión financiera */}
                  <Route path="facturacion" element={<Facturacion />} />
                  <Route path="tienda" element={<Tienda />} />
                  <Route path="inventario" element={<Inventario />} />
                  
                  {/* Reportes */}
                  <Route path="reportes" element={<Reportes />} />
                  <Route path="resultados" element={<Reportes />} />
                  <Route path="historial" element={<Reportes />} />
                  
                  {/* Configuración y perfil */}
                  <Route path="configuracion" element={<Configuracion />} />
                  <Route path="perfil" element={<PerfilUsuario />} />
                  <Route path="actividad" element={<PerfilUsuario />} />
                  
                  {/* Rutas administrativas */}
                  <Route path="admin/menu-config" element={<PanelMenuConfig />} />
                  <Route path="admin/dashboard" element={<AdminDashboardWrapper />} />
                  
                  {/* Super Admin */}
                  <Route path="super-admin" element={<AdminDashboardWrapper />} />
                  <Route path="empresas" element={<AdminDashboardWrapper />} />
                  <Route path="usuarios" element={<Configuracion />} />
                  <Route path="medicos" element={<Pacientes />} />
                  <Route path="sedes" element={<Configuracion />} />
                  
                  {/* Ruta 404 */}
                  <Route path="*" element={<Navigate to="/dashboard" replace />} />
                </Route>
              </Routes>

              {/* Toast notifications espectaculares */}
              <Toaster
                position="top-right"
                toastOptions={{
                  duration: 4000,
                  style: {
                    background: 'rgba(255, 255, 255, 0.95)',
                    color: '#1f2937',
                    backdropFilter: 'blur(10px)',
                    boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)',
                    border: '1px solid rgba(229, 231, 235, 0.5)',
                    borderRadius: '1rem',
                    fontSize: '14px',
                    fontWeight: '500',
                    padding: '16px',
                  },
                  success: {
                    style: {
                      background: 'linear-gradient(135deg, rgba(16, 185, 129, 0.1) 0%, rgba(255, 255, 255, 0.95) 100%)',
                      borderLeft: '4px solid #10B981',
                    },
                    iconTheme: {
                      primary: '#10B981',
                      secondary: '#fff',
                    },
                  },
                  error: {
                    style: {
                      background: 'linear-gradient(135deg, rgba(239, 68, 68, 0.1) 0%, rgba(255, 255, 255, 0.95) 100%)',
                      borderLeft: '4px solid #EF4444',
                    },
                    iconTheme: {
                      primary: '#EF4444',
                      secondary: '#fff',
                    },
                  },
                  loading: {
                    style: {
                      background: 'linear-gradient(135deg, rgba(59, 130, 246, 0.1) 0%, rgba(255, 255, 255, 0.95) 100%)',
                      borderLeft: '4px solid #3B82F6',
                    },
                  },
                }}
              />
            </div>
          </Router>
        </CarritoProvider>
      </SystemProvider>
    </AuthProvider>
  )
}

export default AppNew
