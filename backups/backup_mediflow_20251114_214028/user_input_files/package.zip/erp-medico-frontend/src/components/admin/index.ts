// Exportaciones del módulo administrativo
export { default as PanelAdminFarmacia } from './PanelAdminFarmacia'
export { default as PanelMenuConfig } from './PanelMenuConfig'
export { default as AdminMenuManager } from './AdminMenuManager'
export { default as MenuAdministrationWithProvider } from './MenuAdministrationDemo'