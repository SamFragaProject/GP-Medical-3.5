// Aplicación principal del ERP Médico
import React from 'react'
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'
import { SaaSAuthProvider, useSaaSAuth } from '@/contexts/SaaSAuthContext'
import { CarritoProvider } from '@/contexts/CarritoContext'
import { SystemProvider } from '@/contexts/SystemIntegrationContext'
import { Layout } from '@/components/Layout'
import { ProtectedRoute } from '@/components/ProtectedRoute'
import { PatientLimitedAccess } from '@/components/PatientLimitedAccess'
import { PermissionTester } from '@/components/PermissionTester'
import { PermissionIntegrationTester } from '@/components/PermissionIntegrationTester'
import { NavigationGuard, ROUTE_PERMISSIONS } from '@/components/auth/NavigationGuard'
import { AccessDeniedPage } from '@/components/auth/AccessDeniedPage'
import { PanelMenuConfig } from '@/components/admin/PanelMenuConfig'
import { AdminDashboardWrapper } from '@/components/admin/AdminDashboard'
import { Login } from '@/pages/Login'
import { HomeFunnel } from '@/pages/HomeFunnel'
import { Dashboard } from '@/pages/Dashboard'
import { Agenda } from '@/pages/Agenda'
import { ExamenesOcupacionales } from '@/pages/ExamenesOcupacionales'
import { EvaluacionesRiesgo } from '@/pages/EvaluacionesRiesgo'
import { Reportes } from '@/pages/Reportes'
import { IA } from '@/pages/IA'
import { Facturacion } from '@/pages/Facturacion'
import { Inventario } from '@/pages/Inventario'
import { Configuracion } from '@/pages/Configuracion'
import { Pacientes } from '@/pages/Pacientes'
import { Certificaciones } from '@/pages/Certificaciones'
import { RayosX } from '@/pages/RayosX'
import { NuevaCita } from '@/pages/NuevaCita'
import { PerfilUsuario } from '@/pages/PerfilUsuario'
import { AlertasMedicas } from '@/pages/AlertasMedicas'
import Tienda from '@/pages/Tienda'
import TiendaFarmacia from '@/components/tienda/TiendaFarmacia'
import './App.css'

// Componente para rutas protegidas SaaS
function ProtectedRouteLegacy({ children }: { children: React.ReactNode }) {
  const { user, loading } = useSaaSAuth()

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-white to-green-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-gray-600">Cargando MediFlow...</p>
        </div>
      </div>
    )
  }

  if (!user) {
    return <Navigate to="/login" replace />
  }

  return <>{children}</>
}

// Componente para rutas públicas (redirige si ya está autenticado)
function PublicRoute({ children }: { children: React.ReactNode }) {
  const { user, loading } = useSaaSAuth()

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-white to-green-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-gray-600">Cargando MediFlow...</p>
        </div>
      </div>
    )
  }

  // ✅ SOLUCIÓN: Solo redirigir si hay un usuario Y no está en proceso de login
  // Esto evita conflictos con el flujo de login
  if (user && !loading) {
    return <Navigate to="/dashboard" replace />
  }

  return <>{children}</>
}

// Páginas placeholder para desarrollo futuro
function PaginaEnDesarrollo({ titulo }: { titulo: string }) {
  return (
    <div className="text-center py-16">
      <div className="max-w-md mx-auto">
        <div className="bg-primary/10 p-8 rounded-full w-24 h-24 mx-auto mb-6 flex items-center justify-center">
          <div className="text-primary text-2xl">🚧</div>
        </div>
        <h2 className="text-2xl font-bold text-gray-900 mb-4">{titulo}</h2>
        <p className="text-gray-600 mb-6">
          Esta sección está en desarrollo activo. Próximamente estará disponible con todas las funcionalidades.
        </p>
        <div className="bg-primary/5 border border-primary/20 rounded-lg p-4">
          <h3 className="font-semibold text-primary mb-2">Funcionalidades Planificadas:</h3>
          <ul className="text-sm text-gray-700 space-y-1">
            {titulo === 'Pacientes' && (
              <>
                <li>• Registro completo de empleados</li>
                <li>• Historial médico laboral</li>
                <li>• Gestión de documentos</li>
                <li>• Alertas de seguimiento</li>
              </>
            )}
            {titulo === 'Agenda & Citas' && (
              <>
                <li>• Calendario interactivo</li>
                <li>• Programación automatizada</li>
                <li>• Recordatorios SMS/Email</li>
                <li>• Check-in digital</li>
              </>
            )}
            {titulo === 'Exámenes Ocupacionales' && (
              <>
                <li>• Protocolos personalizados</li>
                <li>• Resultados digitales</li>
                <li>• Certificaciones automáticas</li>
                <li>• Integración con laboratorios</li>
              </>
            )}
            {titulo === 'Evaluaciones de Riesgo' && (
              <>
                <li>• Análisis ergonómico</li>
                <li>• Mediciones ambientales</li>
                <li>• Mapas de calor de riesgo</li>
                <li>• Recomendaciones IA</li>
              </>
            )}
            {titulo === 'Certificaciones Médicas' && (
              <>
                <li>• Generación automática</li>
                <li>• Firma digital</li>
                <li>• Validación blockchain</li>
                <li>• Portal para empresas</li>
              </>
            )}
            {titulo === 'Inventario Médico' && (
              <>
                <li>• Control de stock</li>
                <li>• Alertas de vencimiento</li>
                <li>• Órdenes automáticas</li>
                <li>• Trazabilidad completa</li>
              </>
            )}
            {titulo === 'Facturación & Seguros' && (
              <>
                <li>• CFDI 4.0 automático</li>
                <li>• Integración IMSS/ISSSTE</li>
                <li>• Conciliación automática</li>
                <li>• Reportes fiscales</li>
              </>
            )}
            {titulo === 'Reportes & Analytics' && (
              <>
                <li>• Dashboards interactivos</li>
                <li>• Analytics predictivos</li>
                <li>• Exportación automática</li>
                <li>• KPIs personalizados</li>
              </>
            )}

          </ul>
        </div>
      </div>
    </div>
  )
}

function App() {
  return (
    <SaaSAuthProvider>
      <SystemProvider>
        <CarritoProvider>
        <Router>
        <div className="App">
          <Routes>
            {/* Landing Page - Home Funnel (público) */}
            <Route 
              path="/" 
              element={
                <PublicRoute>
                  <HomeFunnel />
                </PublicRoute>
              } 
            />
            
            {/* Rutas públicas */}
            <Route 
              path="/login" 
              element={
                <PublicRoute>
                  <Login />
                </PublicRoute>
              } 
            />

            {/* Rutas protegidas con NavigationGuard */}
            <Route 
              path="/dashboard" 
              element={
                <ProtectedRoute>
                  <NavigationGuard 
                    routePermissions={[
                      { path: '/dashboard', resource: 'dashboard', action: 'view' }
                    ]}
                  >
                    <Layout />
                  </NavigationGuard>
                </ProtectedRoute>
              }
            >
              {/* Dashboard principal */}
              <Route 
                index 
                element={
                  <NavigationGuard 
                    routePermissions={[
                      { path: '/dashboard', resource: 'dashboard', action: 'view' }
                    ]}
                  >
                    <Dashboard />
                  </NavigationGuard>
                } 
              />
              
              {/* Módulos principales con protección de permisos dinámica */}
              <Route 
                path="pacientes" 
                element={
                  <NavigationGuard 
                    routePermissions={[
                      { 
                        path: '/dashboard/pacientes', 
                        resource: 'patients', 
                        action: 'view',
                        hierarchy: ['admin_empresa', 'medico_trabajo', 'medico_industrial', 'recepcion']
                      }
                    ]}
                  >
                    <Pacientes /> 
                  </NavigationGuard>
                } 
              />
              <Route 
                path="agenda" 
                element={
                  <NavigationGuard 
                    routePermissions={[
                      { 
                        path: '/dashboard/agenda', 
                        resource: 'agenda', 
                        action: 'view',
                        hierarchy: ['admin_empresa', 'medico_trabajo', 'medico_industrial', 'recepcion']
                      }
                    ]}
                  >
                    <Agenda /> 
                  </NavigationGuard>
                } 
              />
              <Route 
                path="agenda/nueva" 
                element={
                  <NavigationGuard 
                    routePermissions={[
                      { 
                        path: '/dashboard/agenda/nueva', 
                        resource: 'agenda', 
                        action: 'create',
                        hierarchy: ['admin_empresa', 'medico_trabajo', 'medico_industrial', 'recepcion']
                      }
                    ]}
                  >
                    <NuevaCita /> 
                  </NavigationGuard>
                } 
              />
              <Route 
                path="alertas" 
                element={
                  <NavigationGuard 
                    routePermissions={[
                      { 
                        path: '/dashboard/alertas', 
                        resource: 'alerts', 
                        action: 'view',
                        hierarchy: ['admin_empresa', 'medico_trabajo', 'medico_industrial']
                      }
                    ]}
                  >
                    <AlertasMedicas /> 
                  </NavigationGuard>
                } 
              />
              
              {/* Medicina del trabajo */}
              <Route 
                path="examenes" 
                element={
                  <NavigationGuard 
                    routePermissions={[
                      { 
                        path: '/dashboard/examenes', 
                        resource: 'exams', 
                        action: 'view',
                        hierarchy: ['admin_empresa', 'medico_trabajo', 'medico_industrial']
                      }
                    ]}
                  >
                    <ExamenesOcupacionales /> 
                  </NavigationGuard>
                } 
              />
              <Route 
                path="rayos-x" 
                element={
                  <NavigationGuard 
                    routePermissions={[
                      { 
                        path: '/dashboard/rayos-x', 
                        resource: 'medical_history', 
                        action: 'view',
                        hierarchy: ['admin_empresa', 'medico_trabajo', 'medico_industrial']
                      }
                    ]}
                  >
                    <RayosX /> 
                  </NavigationGuard>
                } 
              />
              <Route 
                path="evaluaciones" 
                element={
                  <NavigationGuard 
                    routePermissions={[
                      { 
                        path: '/dashboard/evaluaciones', 
                        resource: 'risk_assessments', 
                        action: 'view',
                        hierarchy: ['admin_empresa', 'medico_trabajo', 'medico_industrial']
                      }
                    ]}
                  >
                    <EvaluacionesRiesgo /> 
                  </NavigationGuard>
                } 
              />
              <Route 
                path="ia" 
                element={
                  <NavigationGuard 
                    routePermissions={[
                      { 
                        path: '/dashboard/ia', 
                        resource: 'ai', 
                        action: 'view',
                        hierarchy: ['admin_empresa', 'medico_trabajo', 'medico_industrial']
                      }
                    ]}
                  >
                    <IA /> 
                  </NavigationGuard>
                } 
              />
              <Route 
                path="certificaciones" 
                element={
                  <NavigationGuard 
                    routePermissions={[
                      { 
                        path: '/dashboard/certificaciones', 
                        resource: 'certifications', 
                        action: 'view',
                        hierarchy: ['admin_empresa', 'medico_trabajo', 'medico_industrial']
                      }
                    ]}
                  >
                    <Certificaciones /> 
                  </NavigationGuard>
                } 
              />
              
              {/* Gestión */}
              <Route 
                path="tienda" 
                element={
                  <NavigationGuard 
                    routePermissions={[
                      { 
                        path: '/dashboard/tienda', 
                        resource: 'store', 
                        action: 'view'
                      }
                    ]}
                  >
                    <Tienda /> 
                  </NavigationGuard>
                } 
              />

              <Route 
                path="facturacion" 
                element={
                  <NavigationGuard 
                    routePermissions={[
                      { 
                        path: '/dashboard/facturacion', 
                        resource: 'billing', 
                        action: 'view',
                        hierarchy: ['admin_empresa', 'medico_trabajo', 'recepcion']
                      }
                    ]}
                  >
                    <Facturacion /> 
                  </NavigationGuard>
                } 
              />
              <Route 
                path="reportes" 
                element={
                  <NavigationGuard 
                    routePermissions={[
                      { 
                        path: '/dashboard/reportes', 
                        resource: 'reports', 
                        action: 'view',
                        hierarchy: ['admin_empresa', 'medico_trabajo', 'medico_industrial']
                      }
                    ]}
                  >
                    <Reportes /> 
                  </NavigationGuard>
                } 
              />
              
              {/* Sistema */}
              <Route 
                path="configuracion" 
                element={
                  <NavigationGuard 
                    routePermissions={[
                      { 
                        path: '/dashboard/configuracion', 
                        resource: 'system', 
                        action: 'admin',
                        hierarchy: ['super_admin', 'admin_empresa']
                      }
                    ]}
                  >
                    <Configuracion /> 
                  </NavigationGuard>
                } 
              />
              <Route 
                path="perfil" 
                element={
                  <NavigationGuard 
                    routePermissions={[
                      { path: '/dashboard/perfil', resource: 'profile', action: 'view' }
                    ]}
                  >
                    <PerfilUsuario /> 
                  </NavigationGuard>
                } 
              />
              
              {/* Ruta para acceso limitado de pacientes */}
              <Route 
                path="paciente" 
                element={
                  <NavigationGuard 
                    routePermissions={[
                      { 
                        path: '/dashboard/paciente', 
                        resource: 'patient_portal', 
                        action: 'view',
                        hierarchy: ['paciente']
                      }
                    ]}
                  >
                    <PatientLimitedAccess /> 
                  </NavigationGuard>
                } 
              />
              
              {/* Ruta para pruebas de permisos */}
              <Route 
                path="permission-tester" 
                element={
                  <NavigationGuard 
                    routePermissions={[
                      { 
                        path: '/dashboard/permission-tester', 
                        resource: 'testing', 
                        action: 'view',
                        hierarchy: ['admin_empresa']
                      }
                    ]}
                  >
                    <PermissionTester /> 
                  </NavigationGuard>
                } 
              />
              
              {/* Ruta para testing de integración de permisos */}
              <Route 
                path="integration-tester" 
                element={
                  <NavigationGuard 
                    routePermissions={[
                      { 
                        path: '/dashboard/integration-tester', 
                        resource: 'testing', 
                        action: 'view',
                        hierarchy: ['admin_empresa']
                      }
                    ]}
                  >
                    <PermissionIntegrationTester /> 
                  </NavigationGuard>
                } 
              />

              {/* Ruta para configuración de menús (Solo Super Admin) */}
              <Route 
                path="admin/menu-config" 
                element={
                  <NavigationGuard 
                    routePermissions={[
                      { 
                        path: '/dashboard/admin/menu-config', 
                        resource: 'system', 
                        action: 'admin',
                        hierarchy: ['super_admin']
                      }
                    ]}
                  >
                    <PanelMenuConfig /> 
                  </NavigationGuard>
                } 
              />

              {/* Ruta para dashboard administrativo (Solo Super Admin) */}
              <Route 
                path="admin/dashboard" 
                element={
                  <NavigationGuard 
                    routePermissions={[
                      { 
                        path: '/dashboard/admin/dashboard', 
                        resource: 'system', 
                        action: 'admin',
                        hierarchy: ['super_admin']
                      }
                    ]}
                  >
                    <AdminDashboardWrapper /> 
                  </NavigationGuard>
                } 
              />
            </Route>

            {/* Ruta catch-all */}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>

          {/* Toast notifications */}
          <Toaster
            position="top-right"
            toastOptions={{
              duration: 4000,
              style: {
                background: '#fff',
                color: '#333',
                boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)',
                border: '1px solid #e5e7eb',
                borderRadius: '0.5rem',
                fontSize: '14px',
              },
              success: {
                style: {
                  borderLeft: '4px solid #00BFA6',
                },
                iconTheme: {
                  primary: '#00BFA6',
                  secondary: '#fff',
                },
              },
              error: {
                style: {
                  borderLeft: '4px solid #EF4444',
                },
                iconTheme: {
                  primary: '#EF4444',
                  secondary: '#fff',
                },
              },
            }}
          />
        </div>
      </Router>
        </CarritoProvider>
      </SystemProvider>
    </SaaSAuthProvider>
  )
}

export default App
