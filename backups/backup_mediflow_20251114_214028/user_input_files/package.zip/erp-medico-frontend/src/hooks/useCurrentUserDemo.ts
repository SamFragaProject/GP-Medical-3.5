// Hook para obtener información del usuario actual MODO DEMO - Sin Supabase
import { useState, useEffect, useCallback } from 'react'
import { useSaaSAuth } from '@/contexts/SaaSAuthContext'

interface EmpresaInfo {
  id: string
  nombre: string
  razon_social: string
  rfc: string
  direccion: string
  telefono: string
  email: string
  configuracion: any
  status: 'active' | 'inactive' | 'suspended'
  plan_type: string
  created_at: string
  updated_at: string
}

interface SedeInfo {
  id: string
  empresa_id: string
  nombre: string
  direccion: string
  telefono: string
  email: string
  configuracion: any
  status: 'active' | 'inactive'
  created_at: string
  updated_at: string
}

interface ExtendedUserInfo {
  id: string
  email: string
  name: string
  hierarchy: string
  enterpriseId: string
  enterpriseName: string
  sede: string
  sedeName?: string
  phone?: string
  permissions: string[]
  status: string
  loginCount: number
  createdAt: Date
  updatedAt: Date
  metadata: any
  preferences: any
  empresaInfo?: EmpresaInfo
  sedeInfo?: SedeInfo
  sessionInfo?: {
    lastActivity: Date
    sessionDuration: number
    ipAddress?: string
    userAgent: string
  }
}

interface UserSessionData {
  sessionId: string
  enterpriseId: string
  sedeId?: string
  loginTime: Date
  lastActivity: Date
  ipAddress?: string
  userAgent: string
  permissions: string[]
}

const USER_CACHE_KEY = 'mediflow_current_user_cache'
const SESSION_CACHE_KEY = 'mediflow_user_session_cache'

// Datos de empresa y sede demo
const DEMO_EMPRESA: EmpresaInfo = {
  id: '1',
  nombre: 'MediFlow Corporativo',
  razon_social: 'MediFlow Corporativo S.A. de C.V.',
  rfc: 'MCO123456789',
  direccion: 'Av. Insurgentes Sur 1234, Col. Del Valle, CDMX',
  telefono: '+52 55 1234-5678',
  email: 'contacto@mediflow.mx',
  configuracion: {
    theme: 'light',
    language: 'es',
    notifications: true,
    backup: true
  },
  status: 'active',
  plan_type: 'enterprise',
  created_at: '2024-01-01T00:00:00Z',
  updated_at: '2024-11-04T08:00:00Z'
}

const DEMO_SEDE: SedeInfo = {
  id: '1',
  empresa_id: '1',
  nombre: 'Sede Principal',
  direccion: 'Av. Insurgentes Sur 1234, Col. Del Valle, CDMX',
  telefono: '+52 55 1234-5678',
  email: 'sede.principal@mediflow.mx',
  configuracion: {
    horario_atencion: '08:00-18:00',
    zona_horaria: 'America/Mexico_City',
    idiomas_soportados: ['es', 'en']
  },
  status: 'active',
  created_at: '2024-01-01T00:00:00Z',
  updated_at: '2024-11-04T08:00:00Z'
}

export function useCurrentUser() {
  const { user, loading: authLoading } = useSaaSAuth()
  const [currentUser, setCurrentUser] = useState<ExtendedUserInfo | null>(null)
  const [empresaInfo, setEmpresaInfo] = useState<EmpresaInfo | null>(null)
  const [sedeInfo, setSedeInfo] = useState<SedeInfo | null>(null)
  const [sessionData, setSessionData] = useState<UserSessionData | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  // Cache de datos del usuario
  const getCachedUserData = useCallback((): { user: ExtendedUserInfo; empresa: EmpresaInfo | null; sede: SedeInfo | null } | null => {
    try {
      const cached = localStorage.getItem(USER_CACHE_KEY)
      if (!cached) return null

      const parsed = JSON.parse(cached)
      const now = Date.now()

      // Verificar si el cache es reciente (5 minutos)
      if (now - parsed.timestamp > 5 * 60 * 1000) {
        localStorage.removeItem(USER_CACHE_KEY)
        return null
      }

      return {
        user: parsed.user,
        empresa: parsed.empresa,
        sede: parsed.sede
      }
    } catch (error) {
      console.error('Error leyendo cache de usuario:', error)
      return null
    }
  }, [])

  // Guardar datos del usuario en cache
  const setCachedUserData = useCallback((user: ExtendedUserInfo, empresa: EmpresaInfo | null, sede: SedeInfo | null) => {
    try {
      const cacheData = {
        user,
        empresa,
        sede,
        timestamp: Date.now()
      }
      localStorage.setItem(USER_CACHE_KEY, JSON.stringify(cacheData))
    } catch (error) {
      console.error('Error guardando cache de usuario:', error)
    }
  }, [])

  // Crear o actualizar sesión de usuario DEMO
  const updateUserSession = useCallback(async (userInfo: ExtendedUserInfo) => {
    try {
      const sessionId = crypto.randomUUID()
      const now = new Date()
      
      const sessionInfo: UserSessionData = {
        sessionId,
        enterpriseId: userInfo.enterpriseId,
        sedeId: userInfo.sede,
        loginTime: now,
        lastActivity: now,
        userAgent: navigator.userAgent,
        permissions: userInfo.permissions
      }

      setSessionData(sessionInfo)
      localStorage.setItem(SESSION_CACHE_KEY, JSON.stringify(sessionInfo))

      // En modo demo, solo guardar en localStorage (NO en Supabase)
      console.log('Demo session created:', sessionInfo)

      return sessionId
    } catch (error) {
      console.error('Error actualizando sesión de usuario:', error)
    }
  }, [])

  // Actualizar última actividad DEMO
  const updateLastActivity = useCallback(async () => {
    if (!sessionData) return

    const updatedSession = {
      ...sessionData,
      lastActivity: new Date()
    }

    setSessionData(updatedSession)
    localStorage.setItem(SESSION_CACHE_KEY, JSON.stringify(updatedSession))

    // En modo demo, solo actualizar localStorage (NO en Supabase)
    console.log('Demo activity updated')
  }, [sessionData])

  // Inicializar datos del usuario DEMO
  const initializeUserData = useCallback(async () => {
    if (!user || authLoading) {
      setLoading(false)
      return
    }

    try {
      setLoading(true)
      setError(null)

      // Intentar usar cache primero
      const cached = getCachedUserData()
      if (cached && !cached.user.updatedAt || 
          (user.updatedAt && new Date(user.updatedAt) <= new Date(cached.user.updatedAt))) {
        setCurrentUser(cached.user)
        setEmpresaInfo(cached.empresa)
        setSedeInfo(cached.sede)
        setLoading(false)
        return
      }

      // Usar datos DEMO fijos (NO consultar Supabase)
      const empresa = DEMO_EMPRESA
      const sede = DEMO_SEDE

      const extendedUser: ExtendedUserInfo = {
        ...user,
        enterpriseName: empresa.nombre,
        sedeName: sede.nombre,
        empresaInfo: empresa,
        sedeInfo: sede,
        sessionInfo: {
          lastActivity: new Date(),
          sessionDuration: 0,
          userAgent: navigator.userAgent
        }
      }

      setCurrentUser(extendedUser)
      setEmpresaInfo(empresa)
      setSedeInfo(sede)

      // Actualizar cache
      setCachedUserData(extendedUser, empresa, sede)

      // Actualizar sesión
      await updateUserSession(extendedUser)

    } catch (err) {
      console.error('Error inicializando datos de usuario:', err)
      setError('Error cargando información del usuario')
    } finally {
      setLoading(false)
    }
  }, [user, authLoading, getCachedUserData, setCachedUserData, updateUserSession])

  // Cargar datos al montar o cuando cambie el usuario
  useEffect(() => {
    initializeUserData()
  }, [initializeUserData])

  // Actualizar actividad cada 5 minutos
  useEffect(() => {
    if (!sessionData) return

    const interval = setInterval(updateLastActivity, 5 * 60 * 1000)
    return () => clearInterval(interval)
  }, [sessionData, updateLastActivity])

  // Detectar actividad del usuario y actualizar timestamp
  useEffect(() => {
    if (!sessionData) return

    const events = ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart', 'click']
    let timeoutId: NodeJS.Timeout

    const handleUserActivity = () => {
      clearTimeout(timeoutId)
      timeoutId = setTimeout(() => {
        updateLastActivity()
      }, 30000) // 30 segundos después de la última actividad
    }

    events.forEach(event => {
      document.addEventListener(event, handleUserActivity, true)
    })

    return () => {
      events.forEach(event => {
        document.removeEventListener(event, handleUserActivity, true)
      })
      clearTimeout(timeoutId)
    }
  }, [sessionData, updateLastActivity])

  // Invalidar cache manualmente
  const invalidateCache = useCallback(() => {
    localStorage.removeItem(USER_CACHE_KEY)
    localStorage.removeItem(SESSION_CACHE_KEY)
    initializeUserData()
  }, [initializeUserData])

  // Obtener duración de sesión
  const getSessionDuration = useCallback((): number => {
    if (!sessionData) return 0
    return Date.now() - sessionData.loginTime.getTime()
  }, [sessionData])

  // Verificar si la sesión está activa
  const isSessionActive = useCallback((): boolean => {
    if (!sessionData) return false
    
    const timeSinceLastActivity = Date.now() - sessionData.lastActivity.getTime()
    const SESSION_TIMEOUT = 30 * 60 * 1000 // 30 minutos
    
    return timeSinceLastActivity < SESSION_TIMEOUT
  }, [sessionData])

  // Datos computados
  const userContext = {
    currentUser,
    empresaInfo,
    sedeInfo,
    sessionData,
    loading: loading || authLoading,
    error,
    
    // Funciones utilitarias
    invalidateCache,
    updateLastActivity,
    getSessionDuration,
    isSessionActive,
    
    // Datos derivados
    isSuperAdmin: currentUser?.hierarchy === 'super_admin',
    isAdminEmpresa: currentUser?.hierarchy === 'admin_empresa',
    isMedico: ['medico_trabajo', 'medico_especialista', 'medico_industrial'].includes(currentUser?.hierarchy || ''),
    isPaciente: currentUser?.hierarchy === 'paciente',
    isBot: currentUser?.hierarchy === 'bot',
    
    // Información completa del contexto
    fullUserInfo: {
      ...currentUser,
      empresa: empresaInfo,
      sede: sedeInfo,
      session: sessionData
    }
  }

  return userContext
}