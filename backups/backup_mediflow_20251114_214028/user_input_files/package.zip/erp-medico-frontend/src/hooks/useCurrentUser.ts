// Hook para obtener información del usuario actual - Solo modo demo
import { useState, useEffect, useCallback } from 'react'
import { useSaaSAuth } from '@/contexts/SaaSAuthContext'

interface EmpresaInfo {
  id: string
  nombre: string
  razon_social: string
  rfc: string
  direccion: string
  telefono: string
  email: string
  configuracion: any
  status: 'active' | 'inactive' | 'suspended'
  plan_type: string
  created_at: string
  updated_at: string
}

interface SedeInfo {
  id: string
  empresa_id: string
  nombre: string
  direccion: string
  telefono: string
  email: string
  configuracion: any
  status: 'active' | 'inactive'
  created_at: string
  updated_at: string
}

interface ExtendedUserInfo {
  id: string
  email: string
  name: string
  hierarchy: string
  enterpriseId: string
  enterpriseName: string
  sede: string
  sedeName?: string
  phone?: string
  permissions: string[]
  status: string
  loginCount: number
  createdAt: Date
  updatedAt: Date
  metadata: any
  preferences: any
  empresaInfo?: EmpresaInfo
  sedeInfo?: SedeInfo
  sessionInfo?: {
    lastActivity: Date
    sessionDuration: number
    ipAddress?: string
    userAgent: string
  }
}

interface UserSessionData {
  sessionId: string
  enterpriseId: string
  sedeId?: string
  loginTime: Date
  lastActivity: Date
  ipAddress?: string
  userAgent: string
  permissions: string[]
}

// Datos demo para empresas y sedes
const DEMO_EMPRESAS: Record<string, EmpresaInfo> = {
  'empresa-001': {
    id: 'empresa-001',
    nombre: 'MediFlow Corporativo',
    razon_social: 'MediFlow S.A. de C.V.',
    rfc: 'MED123456789',
    direccion: 'Av. Insurgentes Sur 1234, CDMX',
    telefono: '+52 55 1234-5678',
    email: 'contacto@mediflow.mx',
    configuracion: {},
    status: 'active',
    plan_type: 'enterprise',
    created_at: '2024-01-01T00:00:00Z',
    updated_at: '2024-01-01T00:00:00Z'
  },
  'empresa-002': {
    id: 'empresa-002', 
    nombre: 'Clínica San Rafael',
    razon_social: 'Clínica San Rafael S.A. de C.V.',
    rfc: 'CSR123456789',
    direccion: 'Calle Medicina 456, Guadalajara',
    telefono: '+52 33 2345-6789',
    email: 'info@clinicasanrafael.mx',
    configuracion: {},
    status: 'active',
    plan_type: 'professional',
    created_at: '2024-01-01T00:00:00Z',
    updated_at: '2024-01-01T00:00:00Z'
  }
}

const DEMO_SEDES: Record<string, SedeInfo> = {
  'Matriz CDMX': {
    id: 'sede-001',
    empresa_id: 'empresa-001',
    nombre: 'Matriz CDMX',
    direccion: 'Av. Insurgentes Sur 1234, CDMX',
    telefono: '+52 55 1234-5678',
    email: 'matriz@mediflow.mx',
    configuracion: {},
    status: 'active',
    created_at: '2024-01-01T00:00:00Z',
    updated_at: '2024-01-01T00:00:00Z'
  },
  'Sucursal Norte': {
    id: 'sede-002',
    empresa_id: 'empresa-001',
    nombre: 'Sucursal Norte',
    direccion: 'Av. Norte 789, CDMX',
    telefono: '+52 55 2345-6789',
    email: 'norte@mediflow.mx',
    configuracion: {},
    status: 'active',
    created_at: '2024-01-01T00:00:00Z',
    updated_at: '2024-01-01T00:00:00Z'
  }
}

export function useCurrentUser() {
  const { user, loading: authLoading } = useSaaSAuth()
  const [currentUser, setCurrentUser] = useState<ExtendedUserInfo | null>(null)
  const [empresaInfo, setEmpresaInfo] = useState<EmpresaInfo | null>(null)
  const [sedeInfo, setSedeInfo] = useState<SedeInfo | null>(null)
  const [sessionData, setSessionData] = useState<UserSessionData | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  // Cargar información demo de la empresa
  const loadEmpresaInfo = useCallback(async (empresaId: string): Promise<EmpresaInfo | null> => {
    if (!empresaId) return null
    
    // Simular delay de carga
    await new Promise(resolve => setTimeout(resolve, 100))
    
    return DEMO_EMPRESAS[empresaId] || null
  }, [])

  // Cargar información demo de la sede
  const loadSedeInfo = useCallback(async (sedeName: string): Promise<SedeInfo | null> => {
    if (!sedeName) return null
    
    // Simular delay de carga
    await new Promise(resolve => setTimeout(resolve, 100))
    
    return DEMO_SEDES[sedeName] || null
  }, [])

  // Actualizar datos del usuario
  const updateUserData = useCallback(async () => {
    if (!user) {
      setCurrentUser(null)
      setEmpresaInfo(null)
      setSedeInfo(null)
      setSessionData(null)
      setLoading(false)
      return
    }

    try {
      setLoading(true)
      setError(null)

      // Cargar información de empresa y sede en paralelo
      const [empresa, sede] = await Promise.all([
        loadEmpresaInfo(user.enterpriseId),
        loadSedeInfo(user.sede)
      ])

      const extendedUser: ExtendedUserInfo = {
        id: user.id,
        email: user.email,
        name: user.name,
        hierarchy: user.hierarchy,
        enterpriseId: user.enterpriseId,
        enterpriseName: user.enterpriseName,
        sede: user.sede,
        sedeName: sede?.nombre,
        phone: user.phone,
        permissions: user.permissions,
        status: user.status,
        loginCount: user.loginCount,
        createdAt: user.createdAt,
        updatedAt: user.updatedAt,
        metadata: user.metadata,
        preferences: user.preferences,
        empresaInfo: empresa || undefined,
        sedeInfo: sede || undefined,
        sessionInfo: {
          lastActivity: user.lastActivity || new Date(),
          sessionDuration: Date.now() - (user.sessionInfo?.loginTime.getTime() || Date.now()),
          ipAddress: '127.0.0.1',
          userAgent: navigator.userAgent
        }
      }

      const session: UserSessionData = {
        sessionId: user.sessionInfo?.sessionId || crypto.randomUUID(),
        enterpriseId: user.enterpriseId,
        sedeId: user.sede,
        loginTime: user.sessionInfo?.loginTime || new Date(),
        lastActivity: new Date(),
        ipAddress: '127.0.0.1',
        userAgent: navigator.userAgent,
        permissions: user.permissions
      }

      setCurrentUser(extendedUser)
      setEmpresaInfo(empresa)
      setSedeInfo(sede)
      setSessionData(session)

    } catch (error: any) {
      console.error('Error actualizando datos del usuario:', error)
      setError(error.message)
    } finally {
      setLoading(false)
    }
  }, [user, loadEmpresaInfo, loadSedeInfo])

  // Efecto para cargar datos cuando cambia el usuario
  useEffect(() => {
    if (!authLoading) {
      updateUserData()
    }
  }, [user, authLoading, updateUserData])

  // Funciones de utilidad
  const refreshUserData = useCallback(() => {
    updateUserData()
  }, [updateUserData])

  const hasPermission = useCallback((permission: string): boolean => {
    if (!currentUser?.permissions) return false
    return currentUser.permissions.includes('*') || currentUser.permissions.includes(permission)
  }, [currentUser])

  const isAdmin = useCallback((): boolean => {
    return currentUser?.hierarchy === 'super_admin' || currentUser?.hierarchy === 'admin'
  }, [currentUser])

  const canAccessModule = useCallback((module: string): boolean => {
    return hasPermission(`${module}_view`) || hasPermission(`${module}_manage`) || isAdmin()
  }, [hasPermission, isAdmin])

  return {
    currentUser,
    empresaInfo,
    sedeInfo, 
    sessionData,
    loading: loading || authLoading,
    error,
    refreshUserData,
    hasPermission,
    isAdmin,
    canAccessModule,
    // Funciones adicionales para compatibilidad
    invalidateCache: () => {
      console.log('🗑️ Cache invalidado (modo demo)')
    },
    isSessionActive: () => {
      return !!currentUser && currentUser.status === 'active'
    },
    // Datos adicionales para compatibilidad
    user: currentUser,
    enterprise: empresaInfo,
    sede: sedeInfo
  }
}