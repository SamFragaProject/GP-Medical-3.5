// Componente para testing de integración del sistema de permisos - TEMPORALMENTE DESHABILITADO
// import React, { useState, useEffect } from 'react'
// import { motion } from 'framer-motion'
// import { 
//   Shield, 
//   CheckCircle, 
//   XCircle, 
//   AlertTriangle, 
//   Users, 
//   User, 
//   Building, 
//   MapPin, 
//   Eye, 
//   Settings,
//   RefreshCw,
//   Download,
//   Upload,
//   Database,
//   Clock,
//   Activity,
//   Brain,
//   TestTube
// } from 'lucide-react'

// import { Button } from '@/components/ui/button'
// import { Badge } from '@/components/ui/badge'
// import { Alert, AlertDescription } from '@/components/ui/alert'
// import toast from 'react-hot-toast'

// interface PermissionTest {
//   id: string
//   name: string
//   resource: string
//   action: string
//   expected: boolean
//   description: string
// }

// interface RoleTest {
//   role: string
//   description: string
//   expectedPermissions: string[]
// }

// export function PermissionIntegrationTester() {
//   return (
//     <div className="p-6">
//       <div className="text-center">
//         <h2 className="text-2xl font-bold text-gray-800">Componente Deshabilitado</h2>
//         <p className="text-gray-600">Este componente de testing está temporalmente deshabilitado.</p>
//       </div>
//     </div>
//   )
// }

export default function PermissionIntegrationTester() {
  return (
    <div className="p-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-800">Componente Deshabilitado</h2>
        <p className="text-gray-600">Este componente de testing está temporalmente deshabilitado.</p>
      </div>
    </div>
  )
}
