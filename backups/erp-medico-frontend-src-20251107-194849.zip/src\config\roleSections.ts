// Secciones por rol y metadatos de navegación reutilizables
import { UserRole } from '@/types/auth'
import {
  LayoutDashboard,
  Users,
  Calendar,
  FileText,
  Stethoscope,
  Building2,
  CreditCard,
  Package,
  Settings,
  BarChart3,
  Shield,
  Activity,
  Microscope,
  ClipboardCheck,
  UserCheck,
  Crown
} from 'lucide-react'

export type Section = {
  title: string
  path: string
  resource: string
  icon: React.ElementType
  gradient?: string
  badge?: string | number
}

export const ROLE_SECTIONS: Record<UserRole, Section[]> = {
  super_admin: [
    { title: 'Dashboard', path: '/dashboard', resource: 'dashboard', icon: LayoutDashboard, gradient: 'from-purple-500 to-pink-500' },
    { title: 'Empresas', path: '/empresas', resource: 'empresas', icon: Building2, gradient: 'from-blue-500 to-cyan-500' },
    { title: 'Super Admin', path: '/super-admin', resource: 'sistema', icon: Crown, gradient: 'from-yellow-500 to-orange-500' },
    { title: 'Usuarios', path: '/usuarios', resource: 'usuarios', icon: Users, gradient: 'from-green-500 to-emerald-500' },
    { title: 'Analytics', path: '/analytics', resource: 'analytics', icon: BarChart3, gradient: 'from-indigo-500 to-purple-500' },
    { title: 'Configuración', path: '/configuracion', resource: 'configuracion', icon: Settings, gradient: 'from-gray-500 to-slate-600' }
  ],
  admin_empresa: [
    { title: 'Dashboard', path: '/dashboard', resource: 'dashboard', icon: LayoutDashboard, gradient: 'from-blue-500 to-cyan-500' },
    { title: 'Pacientes', path: '/pacientes', resource: 'pacientes', icon: Users, gradient: 'from-green-500 to-emerald-500' },
    { title: 'Agenda', path: '/agenda', resource: 'citas', icon: Calendar, gradient: 'from-purple-500 to-pink-500' },
    { title: 'Exámenes', path: '/examenes', resource: 'examenes', icon: Stethoscope, gradient: 'from-red-500 to-orange-500' },
    { title: 'Personal Médico', path: '/medicos', resource: 'usuarios', icon: UserCheck, gradient: 'from-teal-500 to-cyan-500' },
    { title: 'Sedes', path: '/sedes', resource: 'sedes', icon: Building2, gradient: 'from-indigo-500 to-blue-500' },
    { title: 'Facturación', path: '/facturacion', resource: 'facturacion', icon: CreditCard, gradient: 'from-yellow-500 to-amber-500' },
    { title: 'Inventario', path: '/inventario', resource: 'inventario', icon: Package, gradient: 'from-lime-500 to-green-500' },
    { title: 'Reportes', path: '/reportes', resource: 'reportes', icon: BarChart3, gradient: 'from-violet-500 to-purple-500' },
    { title: 'Configuración', path: '/configuracion', resource: 'configuracion', icon: Settings, gradient: 'from-gray-500 to-slate-600' }
  ],
  medico: [
    { title: 'Mi Dashboard', path: '/dashboard', resource: 'dashboard', icon: LayoutDashboard, gradient: 'from-green-500 to-emerald-500' },
    { title: 'Mis Pacientes', path: '/pacientes', resource: 'pacientes', icon: Users, gradient: 'from-blue-500 to-cyan-500' },
    { title: 'Mi Agenda', path: '/agenda', resource: 'citas', icon: Calendar, gradient: 'from-purple-500 to-pink-500' },
    { title: 'Exámenes', path: '/examenes', resource: 'examenes', icon: Microscope, gradient: 'from-red-500 to-orange-500' },
    { title: 'Evaluaciones', path: '/evaluaciones', resource: 'evaluaciones', icon: ClipboardCheck, gradient: 'from-teal-500 to-cyan-500' },
    { title: 'Certificaciones', path: '/certificaciones', resource: 'certificaciones', icon: FileText, gradient: 'from-indigo-500 to-blue-500' },
    { title: 'Mis Reportes', path: '/reportes', resource: 'reportes', icon: Activity, gradient: 'from-violet-500 to-purple-500' }
  ],
  paciente: [
    { title: 'Mi Perfil', path: '/perfil', resource: 'perfil', icon: UserCheck, gradient: 'from-orange-500 to-red-500' },
    { title: 'Mis Citas', path: '/citas', resource: 'citas', icon: Calendar, gradient: 'from-purple-500 to-pink-500' },
    { title: 'Mis Exámenes', path: '/examenes', resource: 'examenes', icon: Stethoscope, gradient: 'from-blue-500 to-cyan-500' },
    { title: 'Mis Resultados', path: '/resultados', resource: 'reportes', icon: FileText, gradient: 'from-green-500 to-emerald-500' },
    { title: 'Historial Médico', path: '/historial', resource: 'reportes', icon: Activity, gradient: 'from-indigo-500 to-purple-500' }
  ]
}

export function getSectionsForRole(role: UserRole) {
  return ROLE_SECTIONS[role] || []
}
