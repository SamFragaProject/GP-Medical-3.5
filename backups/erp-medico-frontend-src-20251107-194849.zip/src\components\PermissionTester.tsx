// Componente de pruebas para verificar el sistema de permisos - TEMPORALMENTE DESHABILITADO

export default function PermissionTester() {
  return (
    <div className="p-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-800">Componente Deshabilitado</h2>
        <p className="text-gray-600">Este componente de testing está temporalmente deshabilitado.</p>
      </div>
    </div>
  )
}
